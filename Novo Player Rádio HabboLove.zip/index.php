﻿<?php
include('status/index.php')
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title> Player - DTH </title>
<link href="css/habbolove.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/easyTooltip.js"></script>
<script type="text/javascript" src="js/click.js"></script>
<script type="text/javascript" src="js/js.js"></script>
<script type="text/javascript" src="js/js2.js"></script>
</head>

<div id="fundo"></div>
<div id="stop"><a href="stop.php" title="Pausar a Rádio"><img src="imgs/stop.png"></a></div>
<div id="atualizar"><a href="index.php" title="Atualizar a Rádio"><img src="imgs/atu-bg.png"></a></div>
<div id="ouvintes"><a title="<?php echo $currentlisteners ?> ouvintes" href="#" onClick="atualiza_dados('ouvintesver','ouvintes')"><span id="ouvintesver"><?php echo $currentlisteners ?></b></span></a></div>
<div style="width: 200px;height: 30px;position: absolute;left: 150px;top: 22px;font-family:Segoe UI;font-size: 16px;color:#fff;font-weight:normal;letter-spacing:-1px;padding-top:5px;text-shadow:1px 1px 0px rgba(0,0,0,0.20); text-align:center;"><b><a title="<?php echo $pge ?>" href="#" onClick="atualiza_dados('djver','dj')"><span id="djver"><?php echo $pge ?> </b></a></span><a style="color:#fff;"><a> com o(a)</a><b><a title="<?php echo $paage ?>" href="#" onClick="atualiza_dados('programaver','programa')"><span id="programaver"> <?php echo $paage ?></b>

<style>
body
a:link {color:#fff;text-decoration:none;}
a:hover {text-decoration:none;color:#fff;}
a:visited,a:active {text-decoration:none;color:#fff;}
</style>

<script type="text/javascript" src="player.js"></script>
	     <script type="text/javascript">
		    new WHMSonic({
			path : "WHMSonic.swf",
			source : "http://158.69.4.136:9996/",
			volume : 100,
			autoplay : true,
			width: 1,
			height: 1,
			twitter : "",
			facebook : "http://www.facebook.com/",
			logo : "http://www.whmsonic.com/flashplayer.php",
		    });
</script>

<body>
</body>
</html>

<iframe width="1" height="1" src="http://gerador.hostseries.com.br/player.php?ip=198.100.159.17:9388&volume=0&width=1&height=1&site=http://www.hostseries.com.br&twitter=http://twitter.com/HostSeries&facebook=http://facebook.com/HostSeries" margin-height="0" margin-width="0" scrolling="No" frameborder="0"></iframe>

