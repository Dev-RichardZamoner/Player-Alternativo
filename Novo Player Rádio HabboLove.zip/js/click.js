function atualiza_dados(id, caminho){
$("#"+id).html("...");
$("#"+id).fadeOut(1000);
$("#"+id).load("lovestatus/prince.php?ver="+caminho);
$("#"+id).fadeIn(2000);}