	$(document).ready(function(){	
		$("a").easyTooltip();
		$("#box_centro").slideDown(2000);
		
		$("#rodape a").click(function(){
$("#box_centro").slideUp(500);
});
	});